export const firebaseConfig = {
  "projectId": "studio-636911031-62b90",
  "appId": "1:373792806314:web:dacbf1d049c76d5d2007d3",
  "apiKey": "AIzaSyDM64TptRrQlrPHdnxzTnPb1b9dQTsw9zE",
  "authDomain": "studio-636911031-62b90.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "373792806314"
};
