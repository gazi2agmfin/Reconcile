
import { initializeAdmin } from '@/ai/admin';

// Initialization will be handled within the flows themselves.

import './flows/delete-user-flow';
import './flows/delete-user-data-flow';
import './flows/set-user-password-flow';


